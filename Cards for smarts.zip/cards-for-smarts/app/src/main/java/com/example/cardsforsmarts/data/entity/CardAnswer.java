package com.example.cardsforsmarts.data.entity;

public enum CardAnswer {
    YES, NO
}
